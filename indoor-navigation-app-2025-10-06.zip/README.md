# Indoor Navigation App

This is a standalone indoor navigation web application.

## Features
- Interactive 3D map viewer
- Location selection dropdowns
- Real-time navigation with animated walker
- Responsive design

## Setup
1. Place the GLB model file in the models/ folder
2. Open index.html in a web browser
3. Or run a local server: `python -m http.server 3000`

## Files
- index.html - Main application
- models/ - 3D model files
- data/ - Location and grid data
- package.json - Dependencies
